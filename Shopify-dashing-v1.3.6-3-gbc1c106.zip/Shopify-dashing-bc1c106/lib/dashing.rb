require 'dashing/cli'
require 'dashing/downloader'
require 'dashing/app'

module Dashing
end